//
//  PhotoViewController.swift
//  lab-task-squirrel
//
//  Created by Tutku Gizem Guder on 04.09.24.
//

import Foundation
import UIKit

class PhotoViewController: UIViewController {
    @IBOutlet var UIImageView: UIImageView!
    var task: Task!

  override func viewDidLoad() {
      super.viewDidLoad()
  }
}
